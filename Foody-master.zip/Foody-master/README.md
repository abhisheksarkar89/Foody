# Foody
Food order and delivery application pattern.  
## Feature  
* Easy way to create account or login with Facebook and Google account.
* More options in more places that display for three type: veg and non-veg, all.  
* Search food in City by name or map.  
* Support multiple screen and  orientation(splash screen for sample).  
* Saved Order History. In-time tracking for order.  
* Order food for friends: easily change mobile and delievery address.
* More ways to pay and easy-quick checkout:  PayPal and credit card.    

## Android Version  
5.0 or up   

## Preview  
Multiple screen - [link to preview](https://drive.google.com/open?id=0B9TOHzfzgZXpMHRXeGYzUG9EQlE)  
Application preview - [link to preview](https://drive.google.com/open?id=0B9TOHzfzgZXpeHFvdjcwc0NuYXc)  

## Contact  
Email: liguanzhu390@gamil.com
